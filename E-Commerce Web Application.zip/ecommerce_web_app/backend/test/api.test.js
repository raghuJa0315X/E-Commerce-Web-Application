import test from "node:test";
import assert from "node:assert/strict";
test("project smoke test", async()=>{ assert.equal(typeof (await import("../src/server.js")).app, "function"); });
