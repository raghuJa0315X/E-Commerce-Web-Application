import express from "express";
import cors from "cors";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import Database from "better-sqlite3";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
app.use(cors());
app.use(express.json());
const frontendDir = path.join(__dirname, "../../frontend");
app.use(express.static(frontendDir));
app.get("/", (req, res) => res.sendFile(path.join(frontendDir, "index.html")));

const dataDir = path.join(__dirname, "..", "data");
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(process.env.DB_FILE || path.join(dataDir, "store.db"));
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 email TEXT UNIQUE NOT NULL,
 age INTEGER,
 dob TEXT,
 password TEXT NOT NULL,
 role TEXT NOT NULL CHECK(role IN ('user','admin')) DEFAULT 'user',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS products(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 description TEXT NOT NULL,
 price REAL NOT NULL CHECK(price >= 0),
 image TEXT NOT NULL,
 stock INTEGER NOT NULL DEFAULT 0 CHECK(stock >= 0),
 category TEXT NOT NULL,
 brand TEXT NOT NULL DEFAULT 'NovaCart',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS orders(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL,
 total REAL NOT NULL,
 status TEXT NOT NULL DEFAULT 'Pending',
 shipping_address TEXT NOT NULL,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS order_items(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 order_id INTEGER NOT NULL,
 product_id INTEGER NOT NULL,
 quantity INTEGER NOT NULL CHECK(quantity > 0),
 price REAL NOT NULL,
 FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE,
 FOREIGN KEY(product_id) REFERENCES products(id)
);
`);
if (!db.prepare("PRAGMA table_info(users)").all().some(column => column.name === "age")) db.exec("ALTER TABLE users ADD COLUMN age INTEGER");
if (!db.prepare("PRAGMA table_info(users)").all().some(column => column.name === "dob")) db.exec("ALTER TABLE users ADD COLUMN dob TEXT");
db.exec("CREATE TABLE IF NOT EXISTS app_meta(key TEXT PRIMARY KEY, value TEXT NOT NULL)");
if (!db.prepare("PRAGMA table_info(products)").all().some(column => column.name === "brand")) {
  db.exec("ALTER TABLE products ADD COLUMN brand TEXT NOT NULL DEFAULT 'NovaCart'");
}

const seed = db.prepare("SELECT COUNT(*) AS count FROM products").get();
if (seed.count === 0) {
  const add = db.prepare("INSERT INTO products(name,description,price,image,stock,category) VALUES(?,?,?,?,?,?)");
  const items = [
    ["Wireless Headphones","Premium over-ear headphones with active noise cancellation.",79.99,"https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=800&q=80",25,"Audio"],
    ["Smart Watch","Fitness tracking, notifications and modern design.",129.99,"https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=800&q=80",18,"Wearables"],
    ["Running Shoes","Lightweight everyday running shoes with responsive cushioning.",64.50,"https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=800&q=80",32,"Fashion"],
    ["Mechanical Keyboard","Compact mechanical keyboard with tactile switches.",89.00,"https://images.unsplash.com/photo-1587829741301-dc798b83add3?auto=format&fit=crop&w=800&q=80",15,"Computers"]
  ];
  const tx = db.transaction(() => items.forEach(x => add.run(...x)));
  tx();
}
const expandedCatalog = [
  ["Desk Lamp", "Warm, adjustable LED lamp for focused workspaces.", 34.99, "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=800&q=80", 20, "Home"],
  ["Travel Backpack", "Weather-resistant backpack with a padded laptop sleeve.", 58.00, "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=800&q=80", 14, "Travel"],
  ["Ceramic Coffee Set", "Minimal stoneware mugs for slow mornings and good coffee.", 42.50, "https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?auto=format&fit=crop&w=800&q=80", 10, "Kitchen"],
  ["Everyday Hoodie", "Soft heavyweight cotton hoodie with a relaxed fit.", 49.00, "https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&w=800&q=80", 24, "Fashion"],
  ["Portable Speaker", "Room-filling wireless sound in a compact waterproof body.", 69.99, "https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?auto=format&fit=crop&w=800&q=80", 16, "Audio"],
  ["Yoga Mat", "Cushioned, non-slip mat for home workouts and stretching.", 29.95, "https://images.unsplash.com/photo-1601925260368-ae2f83cf8b7f?auto=format&fit=crop&w=800&q=80", 30, "Wellness"]
  ,["Mechanical Keyboard", "Compact mechanical keyboard with tactile switches.", 89, "https://images.unsplash.com/photo-1587829741301-dc798b83add3?auto=format&fit=crop&w=800&q=80", 15, "Computers"]
  ,["Leather Wallet", "Slim everyday wallet crafted for cards and cash.", 24.5, "https://images.unsplash.com/photo-1627123424574-724758594e93?auto=format&fit=crop&w=800&q=80", 22, "Accessories"]
  ,["Hydrating Face Cream", "Lightweight daily moisturizer for soft, refreshed skin.", 19.99, "https://images.unsplash.com/photo-1556229010-6c3f2c9ca5f8?auto=format&fit=crop&w=800&q=80", 18, "Beauty"]
  ,["Daily Journal", "Premium lined notebook for plans, ideas and reflections.", 12.99, "https://images.unsplash.com/photo-1517842645767-c639042777db?auto=format&fit=crop&w=800&q=80", 40, "Stationery"]
];
const insertProduct = db.prepare("INSERT INTO products(name,description,price,image,stock,category) VALUES(?,?,?,?,?,?)");
for (const item of expandedCatalog) {
  if (!db.prepare("SELECT id FROM products WHERE name=?").get(item[0])) insertProduct.run(...item);
}
const generatedBackpackNames = ["City", "Campus", "Explorer", "Trail", "Commuter", "Weekender", "Minimal", "Studio", "Adventure", "Classic", "Tech", "Eco", "Metro", "Summit", "Daily", "Voyager", "Utility", "Slim", "Outdoor", "Premium"].map(style => `${style} Backpack`);
db.prepare(`DELETE FROM products WHERE name IN (${generatedBackpackNames.map(() => "?").join(",")})`).run(...generatedBackpackNames);
const additionalCategoryProducts = {
  Appliances: "Compact Air Fryer", Automotive: "Car Phone Mount", Books: "Modern Design Guide", Cameras: "Compact Digital Camera", Electronics: "Portable Charger",
  Footwear: "Everyday Sneakers", Furniture: "Oak Side Table", Garden: "Indoor Herb Kit", Grocery: "Organic Snack Box", Health: "Digital Thermometer",
  Jewelry: "Silver Chain Bracelet", Kitchen: "Chef Knife Set", Lighting: "Ambient Floor Light", Mobile: "Protective Phone Case", "Musical Instruments": "Mini Keyboard",
  Office: "Ergonomic Office Chair", "Pet Supplies": "Pet Grooming Brush", Sports: "Training Football", Toys: "Building Blocks Set", Watches: "Classic Leather Watch"
};
const additionalProductImages = {"Compact Air Fryer":"photo-1585515320310-259814833e62","Car Phone Mount":"photo-1516321318423-f06f85e504b3","Modern Design Guide":"photo-1544947950-fa07a98d237f","Compact Digital Camera":"photo-1516035069371-29a1b244cc32","Portable Charger":"photo-1625842268584-8f3296236761","Everyday Sneakers":"photo-1525966222134-fcfa99b8ae77","Oak Side Table":"photo-1538688525198-9b88f6f53126","Indoor Herb Kit":"photo-1416879595882-3373a0480b5b","Organic Snack Box":"photo-1542838132-92c53300491e","Digital Thermometer":"photo-1584308666744-24d5c474f2ae","Silver Chain Bracelet":"photo-1515562141207-7a88fb7ce338","Chef Knife Set":"photo-1593618998160-e34014e67546","Ambient Floor Light":"photo-1513506003901-1e6a229e2d15","Protective Phone Case":"photo-1601784551446-20c9e07cdbdb","Mini Keyboard":"photo-1595225476474-87563907a212","Ergonomic Office Chair":"photo-1503602642458-232111445657","Pet Grooming Brush":"photo-1583337130417-3346a1be7dee","Training Football":"photo-1579952363873-27f3bade9f55","Building Blocks Set":"photo-1596461404969-9ae70f2830c1","Classic Leather Watch":"photo-1524805444758-089113d48a6d"};
Object.entries(additionalCategoryProducts).forEach(([category, name], index) => {
  const image = `https://images.unsplash.com/${additionalProductImages[name]}?auto=format&fit=crop&w=800&q=80`;
  if (!db.prepare("SELECT id FROM products WHERE name=?").get(name)) insertProduct.run(name, `A useful ${category.toLowerCase()} pick for everyday life.`, 24.99 + index * 4.5, image, 12 + index, category);
  else db.prepare("UPDATE products SET image=? WHERE name=?").run(image, name);
});
if (!db.prepare("SELECT value FROM app_meta WHERE key=?").get("catalog_price_v2")) {
  db.exec("UPDATE products SET price=ROUND(price * 1.2, 2)");
  db.prepare("INSERT INTO app_meta(key,value) VALUES(?,?)").run("catalog_price_v2", "20-percent-increase");
}
if (!db.prepare("SELECT value FROM app_meta WHERE key=?").get("catalog_price_v3")) {
  db.exec("UPDATE products SET price=ROUND(price * 30, 2)");
  db.prepare("INSERT INTO app_meta(key,value) VALUES(?,?)").run("catalog_price_v3", "current-inr-prices");
}
const admin = db.prepare("SELECT id FROM users WHERE email=?").get("admin@example.com");
if (!admin) {
  db.prepare("INSERT INTO users(name,email,password,role) VALUES(?,?,?,?)")
    .run("Administrator","admin@example.com",bcrypt.hashSync("Admin@123",10),"admin");
}

const JWT_SECRET = process.env.JWT_SECRET || "development_secret_change_me";

function auth(req,res,next){
  const h=req.headers.authorization;
  if(!h?.startsWith("Bearer ")) return res.status(401).json({message:"Authentication required"});
  try { req.user=jwt.verify(h.slice(7),JWT_SECRET); next(); }
  catch { res.status(401).json({message:"Invalid or expired token"}); }
}
function adminOnly(req,res,next){ if(req.user.role!=="admin") return res.status(403).json({message:"Admin access required"}); next(); }
function sign(user){ return jwt.sign({id:user.id,name:user.name,email:user.email,dob:user.dob,role:user.role},JWT_SECRET,{expiresIn:"2h"}); }
function validDob(value){ if(value===""||value===undefined)return true; const date=new Date(`${value}T00:00:00`); return /^\d{4}-\d{2}-\d{2}$/.test(value)&&!Number.isNaN(date.getTime())&&date<=new Date(); }

app.get("/api/health",(req,res)=>res.json({ok:true,service:"ecommerce-api"}));

app.post("/api/auth/register",(req,res)=>{
  const {name,email,password,dob}=req.body;
  if(!name||!email||!password||password.length<6||!dob||!validDob(dob)) return res.status(400).json({message:"Name, email, password (6+ chars), and date of birth are required"});
  try{
    const result=db.prepare("INSERT INTO users(name,email,dob,password) VALUES(?,?,?,?)").run(name,email.toLowerCase(),dob||null,bcrypt.hashSync(password,10));
    const user=db.prepare("SELECT id,name,email,dob,role FROM users WHERE id=?").get(result.lastInsertRowid);
    res.status(201).json({user,token:sign(user)});
  }catch{res.status(409).json({message:"Email is already registered"});}
});
app.post("/api/auth/login",(req,res)=>{
  const {email,password}=req.body;
  const user=db.prepare("SELECT * FROM users WHERE email=?").get((email||"").toLowerCase());
  if(!user||!bcrypt.compareSync(password||"",user.password)) return res.status(401).json({message:"Invalid email or password"});
  const safe={id:user.id,name:user.name,email:user.email,dob:user.dob,role:user.role};
  res.json({user:safe,token:sign(safe)});
});
app.patch("/api/users/me",auth,(req,res)=>{
  const {name,dob}=req.body;
  const current=db.prepare("SELECT dob FROM users WHERE id=?").get(req.user.id);
  const updatedDob=dob===undefined?current?.dob:null;
  if(!name?.trim()||!validDob(updatedDob)) return res.status(400).json({message:"Name is required; date of birth must be valid"});
  db.prepare("UPDATE users SET name=?, dob=? WHERE id=?").run(name.trim(),updatedDob||null,req.user.id);
  const user=db.prepare("SELECT id,name,email,dob,role FROM users WHERE id=?").get(req.user.id);
  res.json({user,token:sign(user)});
});

app.get("/api/products",(req,res)=>{
  const {category,search}=req.query;
  let sql="SELECT * FROM products WHERE 1=1", params=[];
  if(category){sql+=" AND category=?";params.push(category)}
  if(search){sql+=" AND (name LIKE ? OR description LIKE ? OR category LIKE ? OR brand LIKE ?)";params.push(`%${search}%`,`%${search}%`,`%${search}%`,`%${search}%`)}
  sql+=" ORDER BY id DESC";
  res.json(db.prepare(sql).all(...params));
});
app.post("/api/products",auth,adminOnly,(req,res)=>{
  const {name,description,price,image,stock,category}=req.body;
  const numericPrice=Number(price), numericStock=Number(stock);
  if(!name?.trim()||!description?.trim()||!image?.trim()||!category?.trim()||!Number.isFinite(numericPrice)||numericPrice<0||!Number.isInteger(numericStock)||numericStock<0) return res.status(400).json({message:"Invalid product data"});
  const r=db.prepare("INSERT INTO products(name,description,price,image,stock,category) VALUES(?,?,?,?,?,?)").run(name.trim(),description.trim(),numericPrice,image.trim(),numericStock,category.trim());
  res.status(201).json(db.prepare("SELECT * FROM products WHERE id=?").get(r.lastInsertRowid));
});
app.put("/api/products/:id",auth,adminOnly,(req,res)=>{
  const {name,description,price,image,stock,category}=req.body;
  const numericPrice=Number(price), numericStock=Number(stock);
  if(!name?.trim()||!description?.trim()||!image?.trim()||!category?.trim()||!Number.isFinite(numericPrice)||numericPrice<0||!Number.isInteger(numericStock)||numericStock<0) return res.status(400).json({message:"Invalid product data"});
  const r=db.prepare("UPDATE products SET name=?,description=?,price=?,image=?,stock=?,category=? WHERE id=?")
    .run(name.trim(),description.trim(),numericPrice,image.trim(),numericStock,category.trim(),req.params.id);
  if(!r.changes)return res.status(404).json({message:"Product not found"});
  res.json(db.prepare("SELECT * FROM products WHERE id=?").get(req.params.id));
});
app.delete("/api/products/:id",auth,adminOnly,(req,res)=>{
  try{
    const r=db.prepare("DELETE FROM products WHERE id=?").run(req.params.id);
    if(!r.changes)return res.status(404).json({message:"Product not found"});
    res.json({message:"Product deleted"});
  }catch{res.status(409).json({message:"Product cannot be deleted because it is used in an order"});}
});

app.post("/api/orders",auth,(req,res)=>{
  const {items,shippingAddress}=req.body;
  if(!Array.isArray(items)||items.length===0||!shippingAddress) return res.status(400).json({message:"Cart and shipping address are required"});
  const createOrder=db.transaction(()=>{
    let total=0, rows=[];
    const grouped=new Map();
    for(const item of items){
      const productId=Number(item.productId), q=Number(item.quantity);
      if(!Number.isInteger(productId)||!Number.isInteger(q)||q<1) throw new Error("Invalid cart item");
      grouped.set(productId,(grouped.get(productId)||0)+q);
    }
    for(const [productId,q] of grouped){
      const p=db.prepare("SELECT * FROM products WHERE id=?").get(productId);
      if(!p||q>p.stock) throw new Error(`Insufficient stock for ${p?.name||"product"}`);
      total+=p.price*q; rows.push({p,q});
    }
    const order=db.prepare("INSERT INTO orders(user_id,total,shipping_address) VALUES(?,?,?)").run(req.user.id,total,shippingAddress);
    const oi=db.prepare("INSERT INTO order_items(order_id,product_id,quantity,price) VALUES(?,?,?,?)");
    const dec=db.prepare("UPDATE products SET stock=stock-? WHERE id=?");
    rows.forEach(({p,q})=>{oi.run(order.lastInsertRowid,p.id,q,p.price);dec.run(q,p.id)});
    return db.prepare("SELECT * FROM orders WHERE id=?").get(order.lastInsertRowid);
  });
  try{res.status(201).json(createOrder())}catch(e){res.status(400).json({message:e.message});}
});
app.get("/api/orders/my",auth,(req,res)=>{
  res.json(db.prepare(`
    SELECT o.*, GROUP_CONCAT(p.name || ' x' || oi.quantity, ', ') items
    FROM orders o JOIN order_items oi ON oi.order_id=o.id JOIN products p ON p.id=oi.product_id
    WHERE o.user_id=? GROUP BY o.id ORDER BY o.id DESC`).all(req.user.id));
});
app.get("/api/orders",auth,adminOnly,(req,res)=>{
  res.json(db.prepare(`
    SELECT o.*, u.name customer_name, u.email customer_email,
    GROUP_CONCAT(p.name || ' x' || oi.quantity, ', ') items
    FROM orders o JOIN users u ON u.id=o.user_id
    JOIN order_items oi ON oi.order_id=o.id JOIN products p ON p.id=oi.product_id
    GROUP BY o.id ORDER BY o.id DESC`).all());
});
app.patch("/api/orders/:id/status",auth,adminOnly,(req,res)=>{
  const allowed=["Pending","Processing","Shipped","Delivered","Cancelled"];
  if(!allowed.includes(req.body.status))return res.status(400).json({message:"Invalid status"});
  const r=db.prepare("UPDATE orders SET status=? WHERE id=?").run(req.body.status,req.params.id);
  if(!r.changes)return res.status(404).json({message:"Order not found"});
  res.json(db.prepare("SELECT * FROM orders WHERE id=?").get(req.params.id));
});

app.use((err,req,res,next)=>{console.error(err);res.status(500).json({message:"Internal server error"});});
const port=process.env.PORT||5000;
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  app.listen(port,()=>console.log(`API running at http://localhost:${port}`));
}
export { app };
