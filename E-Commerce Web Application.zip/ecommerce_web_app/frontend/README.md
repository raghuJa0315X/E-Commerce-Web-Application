# NovaCart — Professional E-Commerce Web Application

A polished full-stack online store demo with a responsive storefront, product catalog, persistent cart, authentication, role-based access, checkout, order tracking and an admin console.

## Stack
- Frontend: HTML5, CSS3, Vanilla JavaScript
- Backend: Node.js + Express
- Database: SQLite via better-sqlite3
- Authentication: JWT + bcrypt

## Included features
- Professional responsive home/storefront
- Hero section, trust highlights and curated product categories
- Product search, category filters and sorting
- Product quick-view modal
- Favorites/wishlist stored in localStorage
- Persistent shopping cart with quantity controls
- Stock-aware checkout and shipping address validation
- User registration/login and logout
- Admin/User role-based UI
- Admin product creation and order status management
- User order history
- Seeded demo products and admin account
- API health endpoint
- Backend smoke test
- Backend serves the frontend and API from the same application origin.

## Run locally
1. Open a terminal in `backend`.
2. Run `npm install`.
3. Run `npm start`.
4. Open the application URL shown in the server terminal.

The API health check is available at `/api/health`.

## Demo admin
- Email: `admin@example.com`
- Password: `Admin@123`

Change these credentials and the JWT secret before any real deployment.

## Tests
Run inside `backend`:

```bash
npm test
```

## Production checklist
For a real deployment, add HTTPS, environment-managed secrets, payment provider integration, rate limiting, stronger validation, image storage/CDN, database migrations, audit logging, CSRF protection where applicable, secure cookies/token strategy, backups and a production frontend build/deployment pipeline.
